/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication14;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main implements ActionListener {

public Main() {
initComponents();
}

private JFrame viewForm;

private void initComponents() {
viewForm = new JFrame("Sanieva");
viewForm.setSize(400, 400);
viewForm.setVisible(true);
viewForm.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

JButton but = new JButton("Начать работу");
but.setVisible(true);
but.setLocation(200, 130);
but.setSize(120, 70);

JButton button = new JButton("Подробнее");
button.setVisible(true);
button.setLocation(17, 130);
button.setSize(185, 70);
button.addActionListener(new ActionListener() {

//FileReader fr = new FileReader("D:/workspace/Test/1.txt");
//BufferedReader br = new BufferedReader(fr);
//LineNumberReader lr = new LineNumberReader(br);
//while ((s = lr.readLine()) != null) {
//sb.append(s);
//sb.append("\n");
//}

public void actionPerformed(ActionEvent e) {
// JOptionPane.showMessageDialog(viewForm, "ghjkl",
// "Справка", JOptionPane.WARNING_MESSAGE);
// 
// }
//class Izfile {
//public static void main(String[] args) {
new Izfile21("Текст", 400, 400);

}

});
viewForm.getContentPane().add(button);
viewForm.getContentPane().add(new JLabel());
viewForm.getContentPane().add(but);
viewForm.getContentPane().add(new JLabel());
}

public void actionPerformed(ActionEvent action) {
}

public static void main(String[] args) {
SwingUtilities.invokeLater(new Runnable() {
public void run() {
new Main();
}
});
}

    private static class Izfile21 {

        public Izfile21(String текст, int i, int i0) {
        }
    }
}
